-- =====================================================
--  PersonalIS database setup  (run once in phpMyAdmin / MySQL Workbench)
-- =====================================================
CREATE DATABASE IF NOT EXISTS personalis_db;
USE personalis_db;

-- Login accounts (password is stored hashed with SHA-256)
CREATE TABLE IF NOT EXISTS users (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(64) NOT NULL
);

-- Default login:  username = admin   password = admin123
INSERT INTO users (username, password)
VALUES ('admin', SHA2('admin123', 256));

-- Personal information records
CREATE TABLE IF NOT EXISTS information (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    first_name   VARCHAR(50)  NOT NULL,
    middle_name  VARCHAR(50),
    last_name    VARCHAR(50)  NOT NULL,
    gender       VARCHAR(10)  NOT NULL,
    birthdate    DATE         NOT NULL,
    civil_status VARCHAR(20)  NOT NULL,
    contact_no   VARCHAR(20)  NOT NULL,
    email        VARCHAR(100),
    address      VARCHAR(255) NOT NULL
);

-- Optional sample data
INSERT INTO information (first_name, middle_name, last_name, gender, birthdate, civil_status, contact_no, email, address)
VALUES ('Juan', 'Santos', 'Dela Cruz', 'Male', '2003-05-21', 'Single', '09171234567', 'juan@gmail.com', 'Bayombong, Nueva Vizcaya'),
       ('Maria', '', 'Reyes', 'Female', '2002-11-02', 'Single', '09281234567', 'maria@gmail.com', 'Solano, Nueva Vizcaya');

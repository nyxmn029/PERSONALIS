package personalis;

import java.time.LocalDate;
import java.time.Period;

/**
 * OOP CONCEPTS USED HERE:
 *  - ABSTRACTION   : Person is an abstract class; it cannot be instantiated and
 *                    forces child classes to define getFullName().
 *  - ENCAPSULATION : all fields are private and are accessed through getters/setters.
 */
public abstract class Person {

    private String firstName;
    private String middleName;
    private String lastName;
    private String gender;
    private LocalDate birthdate;

    public Person() {
    }

    public Person(String firstName, String middleName, String lastName,
                  String gender, LocalDate birthdate) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.gender = gender;
        this.birthdate = birthdate;
    }

    // ----- abstract method: every kind of Person decides how its name is shown -----
    public abstract String getFullName();

    // ----- concrete method shared by all children -----
    public int getAge() {
        if (birthdate == null) {
            return 0;
        }
        return Period.between(birthdate, LocalDate.now()).getYears();
    }

    // ----- getters and setters (encapsulation) -----
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public LocalDate getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(LocalDate birthdate) {
        this.birthdate = birthdate;
    }
}

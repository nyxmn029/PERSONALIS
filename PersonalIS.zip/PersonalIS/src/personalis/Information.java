package personalis;

import java.time.LocalDate;

/**
 * One record of the Personal Information System.
 *
 * OOP CONCEPTS USED HERE:
 *  - INHERITANCE   : Information extends Person (reuses name, gender, birthdate).
 *  - POLYMORPHISM  : overrides getFullName() and toString().
 *  - ENCAPSULATION : private fields with getters/setters.
 *
 * @author NINGMEI
 */
public class Information extends Person {

    private int id;
    private String civilStatus;
    private String contactNo;
    private String email;
    private String address;

    public Information() {
        super();
    }

    public Information(int id, String firstName, String middleName, String lastName,
                       String gender, LocalDate birthdate, String civilStatus,
                       String contactNo, String email, String address) {
        super(firstName, middleName, lastName, gender, birthdate);
        this.id = id;
        this.civilStatus = civilStatus;
        this.contactNo = contactNo;
        this.email = email;
        this.address = address;
    }

    /** Polymorphism: our own version of the abstract method in Person. */
    @Override
    public String getFullName() {
        StringBuilder sb = new StringBuilder(getFirstName());
        if (getMiddleName() != null && !getMiddleName().isBlank()) {
            sb.append(' ').append(getMiddleName());
        }
        sb.append(' ').append(getLastName());
        return sb.toString();
    }

    @Override
    public String toString() {
        return "#" + id + " - " + getFullName();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCivilStatus() {
        return civilStatus;
    }

    public void setCivilStatus(String civilStatus) {
        this.civilStatus = civilStatus;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

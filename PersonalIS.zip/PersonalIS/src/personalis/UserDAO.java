package personalis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** Checks the login credentials against the "users" table. */
public class UserDAO {

    public boolean authenticate(String username, String password) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE username = ? AND password = SHA2(?, 256)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
}

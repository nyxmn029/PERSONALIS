package personalis;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Handles the MySQL connection.
 *
 * On the first connection it automatically creates the database, the tables
 * and a default login account, so the program works even on a fresh MySQL.
 *
 * >>> CHANGE DB_USER / DB_PASS below if your MySQL uses other credentials. <<<
 * (XAMPP default: user "root", empty password)
 */
public class DatabaseConnection {

    private static final String DB_NAME = "personalis_db";
    private static final String DB_URL  = "jdbc:mysql://localhost:3306/" + DB_NAME
            + "?createDatabaseIfNotExist=true&useSSL=false"
            + "&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "";

    private static boolean initialized = false;

    private DatabaseConnection() {
        // utility class - no objects needed
    }

    /** Returns a new connection. Callers close it with try-with-resources. */
    public static Connection getConnection() throws SQLException {
        Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
        if (!initialized) {
            createTables(con);
            initialized = true;
        }
        return con;
    }

    private static void createTables(Connection con) throws SQLException {
        try (Statement st = con.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS information ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "first_name VARCHAR(50) NOT NULL, "
                    + "middle_name VARCHAR(50), "
                    + "last_name VARCHAR(50) NOT NULL, "
                    + "gender VARCHAR(10) NOT NULL, "
                    + "birthdate DATE NOT NULL, "
                    + "civil_status VARCHAR(20), "
                    + "contact_no VARCHAR(20), "
                    + "email VARCHAR(100), "
                    + "address VARCHAR(255))");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS users ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "username VARCHAR(50) NOT NULL UNIQUE, "
                    + "password VARCHAR(64) NOT NULL)");

            // default account: admin / admin123 (stored as a SHA-256 hash)
            st.executeUpdate("INSERT IGNORE INTO users (username, password) "
                    + "VALUES ('admin', SHA2('admin123', 256))");
        }
    }
}

package personalis;

import java.sql.SQLException;
import java.util.List;

/**
 * ABSTRACTION (interface): describes WHAT a data class must be able to do,
 * without saying HOW. InformationDAO provides the MySQL implementation.
 */
public interface Crud<T> {

    boolean add(T item) throws SQLException;

    boolean update(T item) throws SQLException;

    boolean delete(int id) throws SQLException;

    T findById(int id) throws SQLException;

    List<T> getAll() throws SQLException;

    List<T> search(String keyword) throws SQLException;
}

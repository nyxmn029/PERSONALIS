package personalis;


public class InformationTest {
        public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new PersonalIS().setVisible(true));
    }
}

package personalis;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object: all SQL for the "information" table lives here.
 * Implements the Crud interface (abstraction) for the Information class.
 */
public class InformationDAO implements Crud<Information> {

    private static final String COLUMNS =
            "id, first_name, middle_name, last_name, gender, birthdate, "
            + "civil_status, contact_no, email, address";

    // ------------------------------------------------------------ ADD
    @Override
    public boolean add(Information i) throws SQLException {
        String sql = "INSERT INTO information (first_name, middle_name, last_name, gender, "
                + "birthdate, civil_status, contact_no, email, address) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, i.getFirstName());
            ps.setString(2, i.getMiddleName());
            ps.setString(3, i.getLastName());
            ps.setString(4, i.getGender());
            ps.setDate(5, Date.valueOf(i.getBirthdate()));
            ps.setString(6, i.getCivilStatus());
            ps.setString(7, i.getContactNo());
            ps.setString(8, i.getEmail());
            ps.setString(9, i.getAddress());
            return ps.executeUpdate() > 0;
        }
    }

    // --------------------------------------------------------- UPDATE
    @Override
    public boolean update(Information i) throws SQLException {
        String sql = "UPDATE information SET first_name=?, middle_name=?, last_name=?, "
                + "gender=?, birthdate=?, civil_status=?, contact_no=?, email=?, address=? "
                + "WHERE id=?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, i.getFirstName());
            ps.setString(2, i.getMiddleName());
            ps.setString(3, i.getLastName());
            ps.setString(4, i.getGender());
            ps.setDate(5, Date.valueOf(i.getBirthdate()));
            ps.setString(6, i.getCivilStatus());
            ps.setString(7, i.getContactNo());
            ps.setString(8, i.getEmail());
            ps.setString(9, i.getAddress());
            ps.setInt(10, i.getId());
            return ps.executeUpdate() > 0;
        }
    }

    // --------------------------------------------------------- DELETE
    @Override
    public boolean delete(int id) throws SQLException {
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM information WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // ------------------------------------------------------- FIND ONE
    @Override
    public Information findById(int id) throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM information WHERE id=?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    // ------------------------------------------------------- VIEW ALL
    @Override
    public List<Information> getAll() throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM information ORDER BY id";
        List<Information> list = new ArrayList<>();
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
        }
        return list;
    }

    // --------------------------------------------------------- SEARCH
    @Override
    public List<Information> search(String keyword) throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM information "
                + "WHERE CAST(id AS CHAR) = ? "
                + "OR CONCAT_WS(' ', first_name, middle_name, last_name) LIKE ? "
                + "OR CONCAT_WS(' ', first_name, last_name) LIKE ? "
                + "ORDER BY id";
        List<Information> list = new ArrayList<>();
        String like = "%" + keyword + "%";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, keyword);
            ps.setString(2, like);
            ps.setString(3, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    // ------------------------------------------- row -> object helper
    private Information map(ResultSet rs) throws SQLException {
        return new Information(
                rs.getInt("id"),
                rs.getString("first_name"),
                rs.getString("middle_name"),
                rs.getString("last_name"),
                rs.getString("gender"),
                rs.getDate("birthdate").toLocalDate(),
                rs.getString("civil_status"),
                rs.getString("contact_no"),
                rs.getString("email"),
                rs.getString("address"));
    }
}

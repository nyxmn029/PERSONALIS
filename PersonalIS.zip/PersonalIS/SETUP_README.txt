PERSONAL INFORMATION SYSTEM - SETUP (Apache NetBeans + MySQL)

1. Start MySQL (XAMPP Control Panel -> Start "MySQL", or your MySQL service).
2. Add the MySQL driver to the project (one time):
   - Download "mysql-connector-j" (Platform Independent .zip) from
     https://dev.mysql.com/downloads/connector/j/  and extract the .jar
   - NetBeans: right-click the project -> Properties -> Libraries -> Classpath
     -> "+" -> Add JAR/Folder -> choose mysql-connector-j-x.x.x.jar -> OK
3. If your MySQL password is NOT empty, edit DB_USER / DB_PASS in
   src/personalis/DatabaseConnection.java
4. Run the project (F6). The database "personalis_db", its tables and the
   login account are created automatically on first login.
   Login:  admin / admin123

OOP concepts used: Encapsulation, Inheritance, Abstraction, Polymorphism
  Person (abstract) <- Information | Crud (interface) <- InformationDAO

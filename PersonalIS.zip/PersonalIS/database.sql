-- Optional: the program creates all of this automatically on first login.
-- Run this in phpMyAdmin / MySQL Workbench only if you prefer to set it up by hand.

CREATE DATABASE IF NOT EXISTS personalis_db;
USE personalis_db;

CREATE TABLE IF NOT EXISTS information (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    first_name    VARCHAR(50)  NOT NULL,
    middle_name   VARCHAR(50),
    last_name     VARCHAR(50)  NOT NULL,
    gender        VARCHAR(10)  NOT NULL,
    birthdate     DATE         NOT NULL,
    civil_status  VARCHAR(20),
    contact_no    VARCHAR(20),
    email         VARCHAR(100),
    address       VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS users (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    username  VARCHAR(50) NOT NULL UNIQUE,
    password  VARCHAR(64) NOT NULL
);

-- default login: admin / admin123
INSERT IGNORE INTO users (username, password) VALUES ('admin', SHA2('admin123', 256));
